/**
 * Enhanced XHR Interceptor for Google Maps
 * Captures API responses and extracts lead data in real-time
 */

(function () {
    'use strict';

    console.log('[GMapsLeads] Installing XHR interceptor...');

    // Save original XMLHttpRequest
    const OriginalXHR = window.XMLHttpRequest;

    // Create intercepting XMLHttpRequest
    window.XMLHttpRequest = function () {
        const xhr = new OriginalXHR();
        let requestURL = '';

        // Save original methods
        const originalOpen = xhr.open;
        const originalSend = xhr.send;
        const originalAddEventListener = xhr.addEventListener;

        // Intercept open() to capture URL
        xhr.open = function (method, url, ...args) {
            requestURL = url.toString();
            return originalOpen.apply(xhr, [method, url, ...args]);
        };

        // Intercept send() to add our response handler
        xhr.send = function (...args) {
            // Add load event listener to intercept responses
            const handleResponse = function () {
                try {
                    // Check if this is a completed /search API call
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        if (requestURL && requestURL.indexOf('/search') > -1) {
                            console.log('[GMapsLeads] 🎯 Intercepted /search API');

                            // Try to parse and extract lead data
                            try {
                                const responseData = xhr.response;
                                let parsedData;

                                // Handle different response types
                                if (typeof responseData === 'string') {
                                    // Remove XSSI protection prefix if present
                                    const cleanData = responseData.replace(/^\)\]\}'\n/, '');
                                    parsedData = JSON.parse(cleanData);
                                } else {
                                    parsedData = responseData;
                                }

                                // Extract leads from the parsed data
                                const leads = extractLeadsFromResponse(parsedData);

                                if (leads && leads.length > 0) {
                                    console.log(`[GMapsLeads] ✅ Extracted ${leads.length} leads from API`);

                                    // Dispatch custom event with extracted leads
                                    window.dispatchEvent(new CustomEvent('GMAPS_LEADS_CAPTURED', {
                                        detail: { leads: leads }
                                    }));
                                }
                            } catch (parseError) {
                                console.warn('[GMapsLeads] Could not parse API response:', parseError);
                            }
                        }
                    }
                } catch (error) {
                    console.error('[GMapsLeads] Interception error:', error);
                }
            };

            // Hook both readystatechange and load events
            originalAddEventListener.call(xhr, 'readystatechange', handleResponse);
            originalAddEventListener.call(xhr, 'load', handleResponse);

            // Call original send
            return originalSend.apply(xhr, args);
        };

        return xhr;
    };

    // Copy static properties from original XHR
    window.XMLHttpRequest.UNSENT = OriginalXHR.UNSENT;
    window.XMLHttpRequest.OPENED = OriginalXHR.OPENED;
    window.XMLHttpRequest.HEADERS_RECEIVED = OriginalXHR.HEADERS_RECEIVED;
    window.XMLHttpRequest.LOADING = OriginalXHR.LOADING;
    window.XMLHttpRequest.DONE = OriginalXHR.DONE;

    /**
     * Extract lead data from Google Maps API response
     * The structure is complex and nested, so we search recursively
     */
    function extractLeadsFromResponse(data) {
        const leads = [];

        try {
            // Google Maps API responses are nested arrays
            // We need to search for arrays that contain place information
            function searchForPlaces(obj, depth = 0) {
                if (depth > 15) return; // Prevent infinite recursion

                if (Array.isArray(obj)) {
                    for (const item of obj) {
                        // Check if this looks like a place entry
                        const lead = tryExtractLead(item);
                        if (lead && lead.placeId) {
                            // Check for duplicates
                            if (!leads.find(l => l.placeId === lead.placeId)) {
                                leads.push(lead);
                            }
                        }

                        // Recurse into nested structures
                        if (typeof item === 'object' && item !== null) {
                            searchForPlaces(item, depth + 1);
                        }
                    }
                } else if (typeof obj === 'object' && obj !== null) {
                    for (const key in obj) {
                        searchForPlaces(obj[key], depth + 1);
                    }
                }
            }

            searchForPlaces(data);
        } catch (err) {
            console.error('[GMapsLeads] Error extracting leads:', err);
        }

        return leads;
    }

    /**
     * Try to extract a lead from a potential place object
     */
    function tryExtractLead(item) {
        if (!item || typeof item !== 'object') return null;

        try {
            // Look for place ID - usually in format ChIJ...
            const placeId = findPlaceId(item);
            if (!placeId) return null;

            // Extract other fields
            const name = findString(item, str =>
                str.length > 2 && str.length < 100 && !str.startsWith('http')
            );

            const phone = findString(item, str =>
                /[\+\(]?\d{1,3}[\s\-\.]?\(?\d{3}\)?[\s\-\.]?\d{3}[\s\-\.]?\d{4}/.test(str)
            );

            const website = findString(item, str =>
                (str.startsWith('http://') || str.startsWith('https://')) &&
                !str.includes('google.com') && !str.includes('gstatic.com')
            );

            const address = findString(item, str =>
                str.length > 10 && str.length < 200 &&
                (str.includes(',') || /\d{1,5}\s\w+/.test(str))
            );

            return {
                placeId: placeId,
                name: name || 'Unknown',
                phone: phone,
                website: website,
                address: address
            };
        } catch (err) {
            return null;
        }
    }

    /**
     * Find a place ID in an object (ChIJ format)
     */
    function findPlaceId(obj, depth = 0) {
        if (depth > 10) return null;

        if (typeof obj === 'string' && obj.startsWith('ChIJ')) {
            return obj;
        }

        if (Array.isArray(obj)) {
            for (const item of obj) {
                const result = findPlaceId(item, depth + 1);
                if (result) return result;
            }
        } else if (typeof obj === 'object' && obj !== null) {
            for (const key in obj) {
                const result = findPlaceId(obj[key], depth + 1);
                if (result) return result;
            }
        }

        return null;
    }

    /**
     * Find a string matching a condition in an object
     */
    function findString(obj, condition, depth = 0) {
        if (depth > 10) return undefined;

        if (typeof obj === 'string' && condition(obj)) {
            return obj;
        }

        if (Array.isArray(obj)) {
            for (const item of obj) {
                const result = findString(item, condition, depth + 1);
                if (result) return result;
            }
        } else if (typeof obj === 'object' && obj !== null) {
            for (const key in obj) {
                const result = findString(obj[key], condition, depth + 1);
                if (result) return result;
            }
        }

        return undefined;
    }

    console.log('[GMapsLeads] ✅ XHR interceptor installed with lead extraction');

})();
